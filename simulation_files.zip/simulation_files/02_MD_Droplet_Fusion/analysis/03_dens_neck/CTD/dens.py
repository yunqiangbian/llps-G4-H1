import numpy as np
mass_dna = { 'DA': 134.100, 'DG': 150.100, 'DC': 110.100, 'DT': 125.100, 'DP': 94.970, 'DS': 83.110 }
mass_pro = { 'ALA': 71.090, 'ARG': 156.190, 'ASN': 114.110, 'ASP': 115.090, 'CYS': 103.150, 'GLN': 128.140, 'GLU': 129.120, 'GLY': 57.050, 'HIS': 137.140, 'ILE': 113.160, 'LEU': 113.160, 'LYS': 128.170, 'MET': 131.190, 'PHE': 147.180, 'PRO': 97.120, 'SER': 87.080, 'THR': 101.110, 'TRP': 186.210, 'TYR': 163.180, 'VAL': 99.140 }

mass_unit = 1.66 * ( 10 ** (-21) )
center_x = 0
a = 240.0 * (10 ** (-10))
b = 240.0 * (10 ** (-10))

stride = 100000

flag = 0
fp_pro_name = 'dens_pro_' + str(flag) + '_step.dat'
fp_pro = open(fp_pro_name, 'w')

box_size = 20.0

center = np.loadtxt('../center.dat')

for i in range (6490) :
#    print(i)
#    if i % stride == 0 :
#        flag = flag + stride
#        fp_pro_name = 'dens_pro_' + str(flag) + '_step.dat'
#        fp_pro = open(fp_pro_name, 'w')
    fp_name1 = 'coor_x_pro_' + str(i) + '.dat'
    fp1 = open(fp_name1, 'r')
    conts1 = fp1.readlines()
    fp1.close()

    fp_name2 = 'coor_y_pro_' + str(i) + '.dat'
    fp2 = open(fp_name2, 'r')
    conts2 = fp2.readlines()
    fp2.close()

    fp_name3 = 'coor_z_pro_' + str(i) + '.dat'
    fp3 = open(fp_name3, 'r')
    conts3 = fp3.readlines()
    fp3.close()

    #fp_out_dna = open(fp_out_name1, 'w')


    x_center = center[i][0]
    y_center = center[i][1]
    z_center = center[i][2]

    mass = 0.0
    n_bead = 0
    atom = conts1[1].split()
    res = conts1[1].split()
    coor_x = conts1[2].split()
    coor_y = conts2[2].split()
    coor_z = conts3[2].split()

    for k in range(len(atom)) :
        x = float(coor_x[k])
        y = float(coor_y[k])
        z = float(coor_z[k])
        if x >= x_center-box_size/2 and x <= x_center+box_size/2 :
            if y >= y_center-box_size/2 and y <= y_center+box_size/2 :
                if z >= z_center-box_size/2 and z <= z_center+box_size/2 :
                    mass = mass + mass_pro[res[k]]
                    n_bead += 1

    vol = box_size**3 * (10 ** (-10))**3 * 1000 * 1000
    dens = mass * mass_unit / vol
    line = str(i) + '    ' + str(dens) + '    ' + str(n_bead) + '\n'
    print(line)
    #fp_out_dna.writelines(line)
    fp_pro.writelines(line)
    #fp_out_dna.close()

fp_pro.close()
