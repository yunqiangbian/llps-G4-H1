import numpy as np
cont1 = np.loadtxt('contact_A.dat')
cont2 = np.loadtxt('contact_B.dat')
fp = open('dna_index.dat', 'r')
fp_out = open('H_value.dat', 'w')
dna_ind = fp.readlines()
frame = 5000
cut_off = 5.0
sigma = 1.0
for i in range(frame) :
    line = str(i) + '  '
    fp_out.writelines(line)
    tmp = dna_ind[i].split()
    h = []
    flag = -2
    if int(tmp[1]) != -1 :
        for j in range(1, len(tmp)) :
            ind = int(tmp[j])
            print(cont1[i][ind], cont2[i][ind])
            h1 = 1 / (1 + np.exp(-(cont1[i][ind]-cut_off) / sigma ))
            h2 = 1 / (1 + np.exp(-(cont2[i][ind]-cut_off) / sigma ))
            hs = (h1 + h2) / 2
            h.append(hs)
        h = np.array(h)
        hmax = np.max(h)
        line = str(hmax) + '\n'
        fp_out.writelines(line)
    if int(tmp[1]) == -1 :
        line4 = str(0) + '  \n'
        print(i,i,i,i,)
        fp_out.writelines(line4)
fp_out.close()
