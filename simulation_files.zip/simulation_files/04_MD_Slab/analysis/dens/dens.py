import numpy as np
mass_dna = { 'DA': 134.100, 'DG': 150.100, 'DC': 110.100, 'DT': 125.100, 'DP': 94.970, 'DS': 83.110 }
mass_pro = { 'ALA': 71.090, 'ARG': 156.190, 'ASN': 114.110, 'ASP': 115.090, 'CYS': 103.150, 'GLN': 128.140, 'GLU': 129.120, 'GLY': 57.050, 'HIS': 137.140, 'ILE': 113.160, 'LEU': 113.160, 'LYS': 128.170, 'MET': 131.190, 'PHE': 147.180, 'PRO': 97.120, 'SER': 87.080, 'THR': 101.110, 'TRP': 186.210, 'TYR': 163.180, 'VAL': 99.140 }

mass_unit = 1.66 * ( 10 ** (-21) )
center_x = 0
a = 200.0 * (10 ** (-10))
b = 200.0 * (10 ** (-10))

na = 6.02 * (10 ** (23))
n_pro = 219
n_dna = 65
frame = 10494

fp_pro_name = 'dens_pro.dat'
fp_pro = open(fp_pro_name, 'w')
for i in range (frame) :
    print(i)
#    if i % stride == 0 :
#        flag = flag + stride
#        fp_pro_name = 'dens_pro_' + str(flag) + '_step.dat'
#        fp_pro = open(fp_pro_name, 'w')
    fp_name1 = 'coor_x_pro_' + str(i) + '.dat'
    fp_out_name1 = 'dens_pro_' + str(i) + '.dat'
    fp1 = open(fp_name1, 'r')
    conts1 = fp1.readlines()
    fp1.close()

    #fp_out_dna = open(fp_out_name1, 'w')

    x_min = -1800
    x_max = 1800
    x_bin = 100
    x_incr = (x_max - x_min) / x_bin
    x_start = x_min
    x_slab = x_start

    while x_slab < x_max :
        mass = 0.0
        n = 0
        atom = conts1[0].split()
        res = conts1[1].split()
        coor = conts1[2].split()
        for k in range(len(atom)) :
            x = float(coor[k])
            if x >= x_slab - (x_incr/2) and x < x_slab + (x_incr/2) :
                #mass = mass + mass_pro[res[k]]
                n += 1
        vol = a * b * x_incr * (10 ** (-10)) * 1000
        #dens = mass * mass_unit / vol
        dens_particle = n / na / vol * 1000
        dens_pro = dens_particle / n_pro
        #line = str(i) + '    ' +str(x_slab) + '    ' + str(dens_pro) + '\n'
        line = str(i) + '    ' +str(x_slab) + '    ' + str(n/n_pro) + '\n'
        #fp_out_dna.writelines(line)
        fp_pro.writelines(line)
        x_slab = x_slab + x_incr
    #fp_out_dna.close()
fp_pro.close()

fp_dna_name = 'dens_dna.dat'
fp_dna = open(fp_dna_name, 'w')
for i in range (frame) :
    print(i)
#    if i % stride == 0 :
#        flag = flag + stride
#        fp_pro_name = 'dens_pro_' + str(flag) + '_step.dat'
#        fp_pro = open(fp_pro_name, 'w')
    fp_name1 = 'coor_x_dna_' + str(i) + '.dat'
    fp_out_name1 = 'dens_dna_' + str(i) + '.dat'
    fp1 = open(fp_name1, 'r')
    conts1 = fp1.readlines()
    fp1.close()

    #fp_out_dna = open(fp_out_name1, 'w')

    x_min = -1800
    x_max = 1800
    x_bin = 100
    x_incr = (x_max - x_min) / x_bin
    x_start = x_min
    x_slab = x_start

    while x_slab < x_max :
        mass = 0.0
        n = 0
        atom = conts1[0].split()
        res = conts1[1].split()
        coor = conts1[2].split()
        for k in range(len(atom)) :
            x = float(coor[k])
            if x >= x_slab - (x_incr/2) and x < x_slab + (x_incr/2) :
                #mass = mass + mass_pro[res[k]]
                n += 1
        vol = a * b * x_incr * (10 ** (-10)) * 1000
        #dens = mass * mass_unit / vol
        dens_particle = n / na / vol * 1000
        dens_dna = dens_particle / n_dna
        #line = str(i) + '    ' +str(x_slab) + '    ' + str(dens_dna) + '\n'
        line = str(i) + '    ' +str(x_slab) + '    ' + str(n/n_dna) + '\n'
        #fp_out_dna.writelines(line)
        fp_dna.writelines(line)
        x_slab = x_slab + x_incr
    #fp_out_dna.close()
fp_dna.close()
