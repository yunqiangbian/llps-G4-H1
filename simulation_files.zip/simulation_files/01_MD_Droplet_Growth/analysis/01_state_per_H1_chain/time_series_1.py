import numpy as np
fp_in = open('cluster.dat', 'r')
conts = fp_in.readlines()
fp_in.close()
fp_out = open('cluster_size.dat', 'w')

line_id = 1
while line_id < len(conts) :
    line = conts[line_id]
    line_len = len(line)
    for i in range(line_len) :
        if line[i]== '[' :
            line_out = line[i:line_len]
            #print(line_out)
            fp_out.writelines(line_out)
            break

    #print(line)
    #fp_out.writelines(line)
    line_id = line_id + 4
fp_out.close()
