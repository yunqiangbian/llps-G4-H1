import mdtraj as md
import numpy as np
import math
from numba import jit, prange
import cython
#from cython.parallel import prange
from joblib import Parallel, delayed
import multiprocessing
import time
from multiprocessing.dummy import Pool as ThreadPool
import gc
import os

#os.environ["CUDA_VISIBLE_DEVICES"] = "0"

#@jit

def readfile() :
    tt = time.time()
    global dna_start, dna_end, pro_start, pro_end
    dna_start = []
    dna_end = []
    pro_start = []
    pro_end = []

    fp = open('dna_300_h1_60.pdb', 'r')
    conts = fp.readlines()
    fp.close()

    dna_last = 0
    for i in range(len(conts)) :
        if 'CA' in conts[i] :
            dna_last = i - 1
            break

    dna_start.append(0)
    for i in range(dna_last) :
        if 'TER' in conts[i] :
            tmp1 = conts[i+1].split()
            tmp2 = conts[i-1].split()
            dna_start.append(int(tmp1[1]) - 1)
            dna_end.append(int(tmp2[1]) - 1)
    tmp3 = conts[dna_last-1].split()
    dna_end.append(int(tmp3[1]) - 1)

    tmp4 = conts[dna_last+1].split()
    pro_start.append(int(tmp4[1]) - 1)
    for i in range(dna_last + 1, len(conts)-1) :
        if 'TER' in conts[i] :
            tmp1 = conts[i+1].split()
            tmp2 = conts[i-1].split()
            pro_start.append(int(tmp1[1]) - 1)
            pro_end.append(int(tmp2[1]) - 1)
    tmp3 = conts[len(conts)-2].split()
    pro_end.append(int(tmp3[1]) - 1)

    dna_start = np.array(dna_start)
    dna_end = np.array(dna_end)
    pro_start = np.array(pro_start)
    pro_end = np.array(pro_end)

    #print('Time used: {} sec'.format(time.time()-tt))

    return dna_start, dna_end, pro_start, pro_end

def contact_1(i) :
    #frame_id = 0
    n_frame = len(t)
    #dna_ind = []
    tt = time.time()
    flag = 0
    #print(i, dna_ind)
    #col_name = 'col' + str(pro_id)
    #col = np.loadtxt(col_name)
    if col[frame_id][i+1] > 5.0 :
        flag = 1
    #print(frame_id, pro_id, i)
    return flag

def col_file() :
    global col
    col = []
    num_col = 301
    num_fp = 60
    data0 = np.loadtxt('col0')
    data1 = np.loadtxt('col1')
    data2 = np.loadtxt('col2')
    data3 = np.loadtxt('col3')
    data4 = np.loadtxt('col4')
    data5 = np.loadtxt('col5')
    data6 = np.loadtxt('col6')
    data7 = np.loadtxt('col7')
    data8 = np.loadtxt('col8')
    data9 = np.loadtxt('col9')
    data10 = np.loadtxt('col10')
    data11 = np.loadtxt('col11')
    data12 = np.loadtxt('col12')
    data13 = np.loadtxt('col13')
    data14 = np.loadtxt('col14')
    data15 = np.loadtxt('col15')
    data16 = np.loadtxt('col16')
    data17 = np.loadtxt('col17')
    data18 = np.loadtxt('col18')
    data19 = np.loadtxt('col19')
    data20 = np.loadtxt('col20')
    data21 = np.loadtxt('col21')
    data22 = np.loadtxt('col22')
    data23 = np.loadtxt('col23')
    data24 = np.loadtxt('col24')
    data25 = np.loadtxt('col25')
    data26 = np.loadtxt('col26')
    data27 = np.loadtxt('col27')
    data28 = np.loadtxt('col28')
    data29 = np.loadtxt('col29')
    data30 = np.loadtxt('col30')
    data31 = np.loadtxt('col31')
    data32 = np.loadtxt('col32')
    data33 = np.loadtxt('col33')
    data34 = np.loadtxt('col34')
    data35 = np.loadtxt('col35')
    data36 = np.loadtxt('col36')
    data37 = np.loadtxt('col37')
    data38 = np.loadtxt('col38')
    data39 = np.loadtxt('col39')
    data40 = np.loadtxt('col40')
    data41 = np.loadtxt('col41')
    data42 = np.loadtxt('col42')
    data43 = np.loadtxt('col43')
    data44 = np.loadtxt('col44')
    data45 = np.loadtxt('col45')
    data46 = np.loadtxt('col46')
    data47 = np.loadtxt('col47')
    data48 = np.loadtxt('col48')
    data49 = np.loadtxt('col49')
    data50 = np.loadtxt('col50')
    data51 = np.loadtxt('col51')
    data52 = np.loadtxt('col52')
    data53 = np.loadtxt('col53')
    data54 = np.loadtxt('col54')
    data55 = np.loadtxt('col55')
    data56 = np.loadtxt('col56')
    data57 = np.loadtxt('col57')
    data58 = np.loadtxt('col58')
    data59 = np.loadtxt('col59')
    for i in range(n_frame) :
        col_frame = []
        for j in range(num_fp) :
            fp_name = 'col' + str(j)
            col_data = np.loadtxt(fp_name)
            for k in range(1, num_col) :
                print(i, j, k)
                col_frame.append(col_data[i][k])
        col.append(col_frame)
    print(col)

def traj() :
    global t
    t = md.load('../dna_h1_llps.dcd', top='dna_300_h1_60.pdb')


def pro_direct_interaction(cluster) :
    gc.disable()
    cluster_pdb = []
    for i in prange(len(cluster)) :
        pro_id_1 = []
        pro_id_1.append(i)
        for j in prange(len(cluster)) :
            flag = 0
            if j != i :
                #print(j)
                for k in prange(len(cluster[j])) :
                    for l in prange(len(cluster[i])) :
                        #print(cluster[i][l], cluster[j][k])
                        if cluster[i][l] == cluster[j][k] :
                            flag = 1
                            pro_id_1.append(j)
                            break
                    if flag == 1 :
                        break
        cluster_pdb.append(pro_id_1)
    #print(cluster_pdb)
    return cluster_pdb

def cluster(cluster_pdb) :
    cluster_new = []
    pdb_align = []
    gc.disable()

    for i in range(len(cluster_pdb)) :
    #for i in range(2) :
        pro_conn = []
        if i not in pdb_align :
            pdb_align.append(i)
            pro_conn = cluster_pdb[i]
            #print(pro_conn)
            j = 0
            while j < len(cluster_pdb) :
                flag = 0
                if j != i and j not in pdb_align :
                    for k in range(len(cluster_pdb[j])) :
                        for l in range(len(pro_conn)) :
                            #print(pro_conn[l], cluster_pdb[j][k])
                            if pro_conn[l] == cluster_pdb[j][k] :
                                flag = 1
                                #print(i, j, pro_conn, cluster_pdb[j])
                                pro_conn = pro_conn + cluster_pdb[j]
                                #print(pro_conn)
                                #pdb_align.append(j)
                                pdb_align = pdb_align + pro_conn
                                pdb_align = list(set(pdb_align))
                                #print(pdb_align)
                                break
                        if flag == 1 :
                            break
                if flag == 1 :
                    j = 0
                j = j + 1

        pro_conn = set(pro_conn)
        pro_conn = list(pro_conn)
        #print(pdb_align)
        if len(pro_conn) > 0 :
            cluster_new.append(pro_conn)
    #print(cluster_new)
    print(frame_id, cluster_new)
    #print(len(cluster_new))

    num_cluster = len(cluster_new)

    num_pro_mono = 0
    num_pro_olig = 0
    num_pro_drop = 0
    num_dna_mono = 0
    num_dna_olig = 0
    num_dna_drop = 0

    num_pro_dimer = 0
    num_dna_dimer = 0

    num_pro_trp = 0
    num_dna_trp = 0

    num_pro_tet = 0
    num_dna_tet = 0

    num_pro_5_10 = 0
    num_dna_5_10 = 0

    num_pro_10_20 = 0
    num_dna_10_20 = 0

    num_pro_20_30 = 0
    num_dna_20_30 = 0

    num_pro_30_40 = 0
    num_dna_30_40 = 0

    num_pro_40_50 = 0
    num_dna_40_50 = 0

    num_pro_50_60 = 0
    num_dna_50_60 = 0

    cluster_pro_num = []
    cluster_dna_num = []
    cluster_total_num = []
    for i in range(len(cluster_new)) :
        num_pro = len(cluster_new[i])
        cluster_dna = []
        for j in range(num_pro) :
            cluster_dna = cluster_dna + dna_binding[cluster_new[i][j]]
        cluster_dna = set(cluster_dna)
        cluster_dna = list(cluster_dna)
        num_dna = len(cluster_dna)
        cluster_pro_num.append(num_pro)
        cluster_dna_num.append(num_dna)
        num_pro_dna = num_pro + num_dna 
        cluster_total_num.append(num_pro_dna)
        #print(i, num_pro, num_dna)
        if num_pro == 1 :
            num_pro_mono = num_pro_mono + num_pro
            num_dna_mono = num_dna_mono + num_dna
        if num_pro >= 2 and num_pro<= 4 :
            num_pro_olig = num_pro_olig + num_pro
            num_dna_olig = num_dna_olig + num_dna
        if num_pro >= 5 :
            num_pro_drop = num_pro_drop + num_pro
            num_dna_drop = num_dna_drop + num_dna

        if num_pro == 2 :
            num_pro_dimer = num_pro_dimer + num_pro
            num_dna_dimer = num_dna_dimer + num_dna

        if num_pro == 3 :
            num_pro_trp = num_pro_trp + num_pro
            num_dna_trp = num_dna_trp + num_dna

        if num_pro == 4 :
            num_pro_tet = num_pro_tet + num_pro
            num_dna_tet = num_dna_tet + num_dna

        if num_pro >= 5 and num_pro < 10 :
            num_pro_5_10 = num_pro_5_10 + num_pro
            num_dna_5_10 = num_dna_5_10 + num_dna

        if num_pro >= 10 and num_pro < 20 :
            num_pro_10_20 = num_pro_10_20 + num_pro
            num_dna_10_20 = num_dna_10_20 + num_dna

        if num_pro >= 20 and num_pro < 30 :
            num_pro_20_30 = num_pro_20_30 + num_pro
            num_dna_20_30 = num_dna_20_30 + num_dna

        if num_pro >= 30 and num_pro < 40 :
            num_pro_30_40 = num_pro_30_40 + num_pro
            num_dna_30_40 = num_dna_30_40 + num_dna

        if num_pro >= 40 and num_pro < 50 :
            num_pro_40_50 = num_pro_40_50 + num_pro
            num_dna_40_50 = num_dna_40_50 + num_dna

        if num_pro >= 50 :
            num_pro_50_60 = num_pro_50_60 + num_pro
            num_dna_50_60 = num_dna_50_60 + num_dna


    total_dna_num = 300
    total_pro_num = 60
    num_pro_max = 0
    cluster_pro_num = np.array(cluster_pro_num)
    for ii in range(len(cluster_pro_num)) :
        if cluster_pro_num[ii] == np.max(cluster_pro_num) :
            num_pro_max = ii
            break
    f_pro_mono = float(num_pro_mono) / total_pro_num
    f_pro_olig = float(num_pro_olig) / total_pro_num
    f_pro_drop = float(num_pro_drop) / total_pro_num
    f_dna_mono = float(num_dna_mono) / total_dna_num
    f_dna_olig = float(num_dna_olig) / total_dna_num
    f_dna_drop = float(num_dna_drop) / total_dna_num
    f_dna_free = 1 - f_dna_mono - f_dna_olig - f_dna_drop

    f_pro_dimer = float(num_pro_dimer) / total_pro_num
    f_pro_trp = float(num_pro_trp) / total_pro_num
    f_pro_tet = float(num_pro_tet) / total_pro_num
    f_pro_5_10 = float(num_pro_5_10) / total_pro_num
    f_pro_10_20 = float(num_pro_10_20) / total_pro_num
    f_pro_20_30 = float(num_pro_20_30) / total_pro_num
    f_pro_30_40 = float(num_pro_30_40) / total_pro_num
    f_pro_40_50 = float(num_pro_40_50) / total_pro_num
    f_pro_50_60 = float(num_pro_50_60) / total_pro_num

    f_dna_dimer = float(num_dna_dimer) / total_dna_num
    f_dna_trp = float(num_dna_trp) / total_dna_num
    f_dna_tet = float(num_dna_tet) / total_dna_num
    f_dna_5_10 = float(num_dna_5_10) / total_dna_num
    f_dna_10_20 = float(num_dna_10_20) / total_dna_num
    f_dna_20_30 = float(num_dna_20_30) / total_dna_num
    f_dna_30_40 = float(num_dna_30_40) / total_dna_num
    f_dna_40_50 = float(num_dna_40_50) / total_dna_num
    f_dna_50_60 = float(num_dna_50_60) / total_dna_num


    print(frame_id, f_pro_mono, f_pro_olig, f_pro_drop, f_pro_dimer, f_pro_trp, f_pro_tet, f_pro_5_10, f_pro_10_20, f_pro_20_30, f_pro_30_40, f_pro_40_50, f_pro_50_60, f_dna_mono, f_dna_olig, f_dna_drop, f_dna_dimer, f_dna_trp, f_dna_tet, f_dna_5_10, f_dna_10_20, f_dna_20_30, f_dna_30_40, f_dna_40_50, f_dna_50_60, f_dna_free, cluster_pro_num[num_pro_max], cluster_dna_num[num_pro_max], cluster_total_num[num_pro_max], num_cluster)
    line = str(frame_id) + '    ' + str(f_pro_mono) + '    ' + str(f_pro_olig) + '    ' + str(f_pro_drop) + '    ' + str(f_pro_dimer) + '    ' + str(f_pro_trp) + '    ' + str(f_pro_tet) + '    ' + str(f_pro_5_10) + '    ' + str(f_pro_10_20) + '    ' + str(f_pro_20_30) + '    ' + str(f_pro_30_40) + '    ' + str(f_pro_40_50) + '    ' + str(f_pro_50_60) + '    ' + str(f_dna_mono) + '    ' + str(f_dna_olig) + '    ' + str(f_dna_drop) + '    ' + str(f_dna_dimer) + '    ' + str(f_dna_trp) + '    ' + str(f_dna_tet) + '    ' + str(f_dna_5_10) + '    ' + str(f_dna_10_20) + '    ' + str(f_dna_20_30) + '    ' + str(f_dna_30_40) + '    ' + str(f_dna_40_50) + '    ' + str(f_dna_50_60) + '    ' + str(f_dna_free) + '    ' + str(cluster_pro_num[num_pro_max]) + '    ' + str(cluster_dna_num[num_pro_max]) + '    ' + str(cluster_total_num[num_pro_max]) + '    ' + str(num_cluster) + '\n'
    return line

readfile()
traj()
n_frame = len(t)
global frame_id
global pro_id
dna_id = range(len(dna_start))
fp_out = open('traj.dat', 'w')
gc.disable()
#col_file()

fp_dna_matrix = open('dna_matrix.dat', 'w')
fp_pro_matrix = open('pro_matrix.dat', 'w')


for frame_id in range(n_frame) :
    global dna_binding
    global dna_ind
    global col
    dna_binding = []
    tt = time.time()
    #for pro_id in range(len(pro_start)) :
    for pro_id in range(len(pro_start)) :
        col_name = 'col' + str(pro_id)
        col = np.loadtxt(col_name)
        dna_ind = []
        results = Parallel(n_jobs=16, backend='multiprocessing')(delayed(contact_1)(i) for i in dna_id)
        #print("contact matrix is:")
        #print(results)
        for ii in range(len(results)) :
            if results[ii] == 1 :
                dna_ind.append(ii)
        dna_binding.append(dna_ind)
    print(frame_id, dna_binding)
    #print(dna_binding)
    pro_interaction = pro_direct_interaction(dna_binding)
    line_1 = cluster(pro_interaction)
    fp_out.writelines(line_1)
    print(frame_id, 'Time used: {} sec'.format(time.time()-tt))

fp_out.close()
