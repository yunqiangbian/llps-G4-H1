import numpy as np
fp = open('cluster_size.dat', 'r')
conts = fp.readlines()
fp.close()

num_pro = 60

fp_out = open('time_series_h1_id.dat', 'w')

for i in range(len(conts)) :
    a = conts[i].split(']')
    line = '%3d' % (i)
    fp_out.writelines(line)
    for pro_id in range(num_pro) :
        flag = 0
        for j in range(len(a)-2) :
            b = a[j].split()
            cluster_size = len(b)
            for k in range(cluster_size) :
                if pro_id == int(b[k]) :
                    flag = 1
                    break
            if flag == 1 :
                if cluster_size == 1 :
                    cluster_state = 1
                    line = '%3d' % (cluster_state)
                    fp_out.writelines(line)
                if cluster_size == 2 :
                    cluster_state = 2
                    line = '%3d' % (cluster_state)
                    fp_out.writelines(line)
                if cluster_size == 3 :
                    cluster_state = 3
                    line = '%3d' % (cluster_state)
                    fp_out.writelines(line)
                if cluster_size == 4 :
                    cluster_state = 4
                    line = '%3d' % (cluster_state)
                    fp_out.writelines(line)
                if cluster_size >= 5 and cluster_size < 10 :
                    cluster_state = 5
                    line = '%3d' % (cluster_state)
                    fp_out.writelines(line)
                if cluster_size >= 10 and cluster_size < 20 :
                    cluster_state = 6
                    line = '%3d' % (cluster_state)
                    fp_out.writelines(line)
                if cluster_size >= 20 and cluster_size < 30 :
                    cluster_state = 7
                    line = '%3d' % (cluster_state)
                    fp_out.writelines(line)
                if cluster_size >= 30 and cluster_size < 40 :
                    cluster_state = 8
                    line = '%3d' % (cluster_state)
                    fp_out.writelines(line)
                if cluster_size >= 40 and cluster_size < 50 :
                    cluster_state = 9
                    line = '%3d' % (cluster_state)
                    fp_out.writelines(line)
                if cluster_size >= 50 and cluster_size < 60 :
                    cluster_state = 10
                    line = '%3d' % (cluster_state)
                    fp_out.writelines(line)
                break
    fp_out.writelines('\n')
fp_out.close()

data = np.loadtxt('time_series_pro.dat')
fp_out_new = open('time_series_pro_new.dat', 'w')

for i in range(num_pro) :
    index = i + 1
    time = data[:,0]
    state = data[:, index]
    print(index, len(state), len(data[0]))
    for j in range(len(time)) :
        line = '%8d%4d%4d\n' % (time[j], index, state[j])
        fp_out_new.writelines(line)
fp_out_new.close()

