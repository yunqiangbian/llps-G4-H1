import mdtraj as md
import numpy as np
import math
from numba import jit, prange
import cython
#from cython.parallel import prange
from joblib import Parallel, delayed
import multiprocessing
import time
from multiprocessing.dummy import Pool as ThreadPool
import gc
import os

#os.environ["CUDA_VISIBLE_DEVICES"] = "0"

#@jit

def readfile() :
    tt = time.time()
    global dna_start, dna_end, pro_start, pro_end
    dna_start = []
    dna_end = []
    pro_start = []
    pro_end = []

    fp = open('dna_300_h1_60.pdb', 'r')
    conts = fp.readlines()
    fp.close()

    dna_last = 0
    for i in range(len(conts)) :
        if 'CA' in conts[i] :
            dna_last = i - 1
            break

    dna_start.append(0)
    for i in range(dna_last) :
        if 'TER' in conts[i] :
            tmp1 = conts[i+1].split()
            tmp2 = conts[i-1].split()
            dna_start.append(int(tmp1[1]) - 1)
            dna_end.append(int(tmp2[1]) - 1)
    tmp3 = conts[dna_last-1].split()
    dna_end.append(int(tmp3[1]) - 1)

    tmp4 = conts[dna_last+1].split()
    pro_start.append(int(tmp4[1]) - 1)
    for i in range(dna_last + 1, len(conts)-1) :
        if 'TER' in conts[i] :
            tmp1 = conts[i+1].split()
            tmp2 = conts[i-1].split()
            pro_start.append(int(tmp1[1]) - 1)
            pro_end.append(int(tmp2[1]) - 1)
    tmp3 = conts[len(conts)-2].split()
    pro_end.append(int(tmp3[1]) - 1)

    dna_start = np.array(dna_start)
    dna_end = np.array(dna_end)
    pro_start = np.array(pro_start)
    pro_end = np.array(pro_end)

    #print('Time used: {} sec'.format(time.time()-tt))

    return dna_start, dna_end, pro_start, pro_end

@jit
def coor_mol(t, dna_start, dna_end, pro_start, pro_end) :
    n_frame = len(t)
    n_atom = 32640
    tt = time.time()
    for i in range(1) :
        for j in range(650) :
            coor_x_1 = t.xyz[i][j][0]
            coor_y_1 = t.xyz[i][j][1]
            coor_z_1 = t.xyz[i][j][2]
            for k in range(19501, n_atom) :
                coor_x_2 = t.xyz[i][k][0]
                coor_y_2 = t.xyz[i][k][0]
                coor_z_2 = t.xyz[i][k][0]
                dist = np.sqrt((coor_x_1 - coor_x_2)**2 + (coor_y_1 - coor_y_2)**2 + (coor_z_1 - coor_z_2)**2)
                print(j, k, dist)

            #return coor_x, coor_y, coor_z
    print('Time used: {} sec'.format(time.time()-tt))

def contact(x, y) :
    frame_id = 0
    tt = time.time()
    for i in prange(len(dna_start)) :
        flag = 0
        for j in prange(dna_start[i], dna_end[i]+1) :
            coor_x_dna = t.xyz[frame_id][j][0]
            coor_y_dna = t.xyz[frame_id][j][1]
            coor_z_dna = t.xyz[frame_id][j][2]
            print(i, j)
            for k in prange(x, y) :
                coor_x_pro = t.xyz[frame_id][k][0]
                coor_y_pro = t.xyz[frame_id][k][1]
                coor_z_pro = t.xyz[frame_id][k][2]
                dist = np.sqrt((coor_x_dna - coor_x_pro)**2 + (coor_y_dna - coor_y_pro)**2 + (coor_z_dna - coor_z_pro)**2)
                if dist <= 0.5 :
                    flag = 1
                    break
            if flag == 1 :
                break
    print('Time used: {} sec'.format(time.time()-tt))

def contact_1(i) :
    #frame_id = 0
    n_frame = len(t)
    #dna_ind = []
    tt = time.time()
    flag = 0
    #print(i, dna_ind)
    for j in prange(dna_start[i], dna_end[i]+1) :
        coor_x_dna = t.xyz[frame_id][j][0]
        coor_y_dna = t.xyz[frame_id][j][1]
        coor_z_dna = t.xyz[frame_id][j][2]
        #print(i, pro_id)
        for k in prange(pro_start[pro_id], pro_end[pro_id]+1) :
            coor_x_pro = t.xyz[frame_id][k][0]
            coor_y_pro = t.xyz[frame_id][k][1]
            coor_z_pro = t.xyz[frame_id][k][2]
            dist = np.sqrt((coor_x_dna - coor_x_pro)**2 + (coor_y_dna - coor_y_pro)**2 + (coor_z_dna - coor_z_pro)**2)
            #print(i, j, k)
            if dist <= 0.5 :
                flag = 1
                #print(dist, i)
                #dna_ind.append(i)
                #print(dna_ind)
                break
        if flag == 1 :
            break
    return flag
    #dna_binding.append(dna_ind)
    #print(dna_binding)
    #print('Time used: {} sec'.format(time.time()-tt))

def traj() :
    global t
    t = md.load('traj_1.dcd', top='dna_300_h1_60.pdb')


def pro_direct_interaction(cluster) :
    gc.disable()
    cluster_pdb = []
    for i in prange(len(cluster)) :
        pro_id = []
        pro_id.append(i)
        for j in prange(len(cluster)) :
            flag = 0
            if j != i :
                #print(j)
                for k in prange(len(cluster[j])) :
                    for l in prange(len(cluster[i])) :
                        #print(cluster[i][l], cluster[j][k])
                        if cluster[i][l] == cluster[j][k] :
                            flag = 1
                            pro_id.append(j)
                            break
                    if flag == 1 :
                        break
        cluster_pdb.append(pro_id)
    #print(cluster_pdb)
    return cluster_pdb

def cluster(cluster_pdb) :
    cluster_new = []
    pdb_align = []
    gc.disable()

    for i in range(len(cluster_pdb)) :
    #for i in range(2) :
        pro_conn = []
        if i not in pdb_align :
            pdb_align.append(i)
            pro_conn = cluster_pdb[i]
            #print(pro_conn)
            for j in range(len(cluster_pdb)) :
                flag = 0
                if j != i and j not in pdb_align :
                    for k in range(len(cluster_pdb[j])) :
                        for l in range(len(pro_conn)) :
                            #print(pro_conn[l], cluster_pdb[j][k])
                            if pro_conn[l] == cluster_pdb[j][k] :
                                flag = 1
                                #print(i, j, pro_conn, cluster_pdb[j])
                                pro_conn = pro_conn + cluster_pdb[j]
                                #print(pro_conn)
                                #pdb_align.append(j)
                                pdb_align = pdb_align + pro_conn
                                pdb_align = list(set(pdb_align))
                                #print(pdb_align)
                                break
                        if flag == 1 :
                            break
        pro_conn = set(pro_conn)
        pro_conn = list(pro_conn)
        #print(pdb_align)
        if len(pro_conn) > 0 :
            cluster_new.append(pro_conn)
    #print(cluster_new)
    #print(len(cluster_new))

    num_cluster = len(cluster_new)

    num_pro_mono = 0
    num_pro_olig = 0
    num_pro_drop = 0
    num_dna_mono = 0
    num_dna_olig = 0
    num_dna_drop = 0
    cluster_pro_num = []
    cluster_dna_num = []
    cluster_total_num = []
    for i in range(len(cluster_new)) :
        num_pro = len(cluster_new[i])
        cluster_dna = []
        for j in range(num_pro) :
            cluster_dna = cluster_dna + dna_binding[cluster_new[i][j]]
        cluster_dna = set(cluster_dna)
        cluster_dna = list(cluster_dna)
        num_dna = len(cluster_dna)
        cluster_pro_num.append(num_pro)
        cluster_dna_num.append(num_dna)
        num_pro_dna = num_pro + num_dna 
        cluster_total_num.append(num_pro_dna)
        #print(i, num_pro, num_dna)
        if num_pro == 1 :
            num_pro_mono = num_pro_mono + num_pro
            num_dna_mono = num_dna_mono + num_dna
        if num_pro >= 2 and num_pro<= 4 :
            num_pro_olig = num_pro_olig + num_pro
            num_dna_olig = num_dna_olig + num_dna
        if num_pro >= 5 :
            num_pro_drop = num_pro_drop + num_pro
            num_dna_drop = num_dna_drop + num_dna
    total_dna_num = 300
    total_pro_num = 60
    num_pro_max = 0
    cluster_pro_num = np.array(cluster_pro_num)
    for ii in range(len(cluster_pro_num)) :
        if cluster_pro_num[ii] == np.max(cluster_pro_num) :
            num_pro_max = ii
            break
    f_pro_mono = float(num_pro_mono) / total_pro_num
    f_pro_olig = float(num_pro_olig) / total_pro_num
    f_pro_drop = float(num_pro_drop) / total_pro_num
    f_dna_mono = float(num_dna_mono) / total_dna_num
    f_dna_olig = float(num_dna_olig) / total_dna_num
    f_dna_drop = float(num_dna_drop) / total_dna_num
    f_dna_free = 1 - f_dna_mono - f_dna_olig - f_dna_drop
    print(frame_id, f_pro_mono, f_pro_olig, f_pro_drop, f_dna_mono, f_dna_olig, f_dna_drop, f_dna_free, cluster_pro_num[num_pro_max], cluster_dna_num[num_pro_max], cluster_total_num[num_pro_max], num_cluster)
    line = str(frame_id) + '    ' + str(f_pro_mono) + '    ' + str(f_pro_olig) + '    ' + str(f_pro_drop) + '    ' + str(f_dna_mono) + '    ' + str(f_dna_olig) + '    ' + str(f_dna_drop) + '    ' + str(f_dna_free) + '    ' + str(cluster_pro_num[num_pro_max]) + '    ' + str(cluster_dna_num[num_pro_max]) + '    ' + str(cluster_total_num[num_pro_max]) +  '    ' + str(num_cluster) + '\n'
    return line

readfile()
traj()
n_frame = len(t)
global frame_id
global pro_id
dna_id = range(len(dna_start))
fp_out = open('traj.dat', 'w')
gc.disable()

for frame_id in range(n_frame) :
    global dna_binding
    global dna_ind
    dna_binding = []
    tt = time.time()
    #for pro_id in range(len(pro_start)) :
    for pro_id in range(len(pro_start)) :
        dna_ind = []
        results = Parallel(n_jobs=16, backend='multiprocessing')(delayed(contact_1)(i) for i in dna_id)
        #print(dna_ind)
        for ii in range(len(results)) :
            if results[ii] == 1 :
                dna_ind.append(ii)
        dna_binding.append(dna_ind)
        #print(dna_binding)
    pro_interaction = pro_direct_interaction(dna_binding)
    line_1 = cluster(pro_interaction)
    fp_out.writelines(line_1)
    print(frame_id, 'Time used: {} sec'.format(time.time()-tt))

fp_out.close()
