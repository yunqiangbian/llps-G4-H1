import numpy as np
data = np.loadtxt('g4_bind_number.dat')
num = 0
while num <= 10 :
    summ = 0
    for i in range(2000, 3000) :
        if data[i][1] == num :
            summ += 1
    prob = summ / 1000
    print(num, prob)
    num += 1
