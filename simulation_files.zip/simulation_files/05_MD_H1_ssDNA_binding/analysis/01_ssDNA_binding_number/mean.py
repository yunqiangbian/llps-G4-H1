import numpy as np
data1 = np.loadtxt('g4_bind_prob_1.dat')
data2 = np.loadtxt('g4_bind_prob_2.dat')
data3 = np.loadtxt('g4_bind_prob_3.dat')

for i in range(len(data1)) :
    n = data1[:,0][i]
    p = []
    p.append(data1[:,1][i])
    p.append(data2[:,1][i])
    p.append(data3[:,1][i])
    p = np.array(p)
    print(n, np.mean(p), np.std(p))
