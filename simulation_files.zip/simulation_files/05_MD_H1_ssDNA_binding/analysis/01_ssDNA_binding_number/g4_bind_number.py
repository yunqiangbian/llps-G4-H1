import mdtraj as md
import numpy as np
import math

t = md.load('../trajectory/traj.dcd', top='../trajectory/input.pdb')
ca_index = t.topology.select('name CA')

fp = open('rep_2_2_2.pdb', 'r')
conts = fp.readlines()
fp.close()

num_dna = 0
num_dna_atom = 65
num_pro_atom = len(ca_index)

for i in range(len(conts)) :
    line = conts[i]
    if 'TER' in line :
        num_dna = num_dna + 1
num_dna =  num_dna - 1

ind_dna = np.zeros((num_dna, num_dna_atom))
ind_atom = 0
for i in range(num_dna) :
    for j in range(num_dna_atom) :
        ind_dna[i][j] = ind_atom
        ind_atom = ind_atom + 1
#print(ind_dna)

n_frame = len(t)
cut_off = 0.5

fp_out = open('g4_bind_number.dat', 'w')

for i in range(n_frame) :
    num_bind = 0
    num_bind1 = 0
    num_bind2 = 0
    num_bind3 = 0
    for j in range(num_dna) :
        flag = 0
        flag1 = 0
        flag2 = 0
        flag3 = 0
        for k in range(num_dna_atom) :
            coor_x_dna = t.xyz[i][int(ind_dna[j][k])][0]
            coor_y_dna = t.xyz[i][int(ind_dna[j][k])][1]
            coor_z_dna = t.xyz[i][int(ind_dna[j][k])][2]
            for l in range(num_pro_atom) :
                coor_x_pro = t.xyz[i][ca_index[l]][0]
                coor_y_pro = t.xyz[i][ca_index[l]][1]
                coor_z_pro = t.xyz[i][ca_index[l]][2]
                dist = np.sqrt((coor_x_dna - coor_x_pro)**2 + (coor_y_dna - coor_y_pro)**2 + (coor_z_dna - coor_z_pro)**2)
                if dist <= cut_off :
                    flag = 1
                    num_bind = num_bind + 1
                    break
            if flag == 1 :
                break
        for k in range(num_dna_atom) :
            coor_x_dna = t.xyz[i][int(ind_dna[j][k])][0]
            coor_y_dna = t.xyz[i][int(ind_dna[j][k])][1]
            coor_z_dna = t.xyz[i][int(ind_dna[j][k])][2]
            for l in range(39) :
                coor_x_pro = t.xyz[i][ca_index[l]][0]
                coor_y_pro = t.xyz[i][ca_index[l]][1]
                coor_z_pro = t.xyz[i][ca_index[l]][2]
                dist = np.sqrt((coor_x_dna - coor_x_pro)**2 + (coor_y_dna - coor_y_pro)**2 + (coor_z_dna - coor_z_pro)**2)
                if dist <= cut_off :
                    flag1 = 1
                    num_bind1 = num_bind1 + 1
                    break
            if flag1 == 1 :
                break
        for k in range(num_dna_atom) :
            coor_x_dna = t.xyz[i][int(ind_dna[j][k])][0]
            coor_y_dna = t.xyz[i][int(ind_dna[j][k])][1]
            coor_z_dna = t.xyz[i][int(ind_dna[j][k])][2]
            for l in range(39, 117) :
                coor_x_pro = t.xyz[i][ca_index[l]][0]
                coor_y_pro = t.xyz[i][ca_index[l]][1]
                coor_z_pro = t.xyz[i][ca_index[l]][2]
                dist = np.sqrt((coor_x_dna - coor_x_pro)**2 + (coor_y_dna - coor_y_pro)**2 + (coor_z_dna - coor_z_pro)**2)
                if dist <= cut_off :
                    flag2 = 1
                    num_bind2 = num_bind2 + 1
                    break
            if flag2 == 1 :
                break
        for k in range(num_dna_atom) :
            coor_x_dna = t.xyz[i][int(ind_dna[j][k])][0]
            coor_y_dna = t.xyz[i][int(ind_dna[j][k])][1]
            coor_z_dna = t.xyz[i][int(ind_dna[j][k])][2]
            for l in range(117, num_pro_atom) :
                coor_x_pro = t.xyz[i][ca_index[l]][0]
                coor_y_pro = t.xyz[i][ca_index[l]][1]
                coor_z_pro = t.xyz[i][ca_index[l]][2]
                dist = np.sqrt((coor_x_dna - coor_x_pro)**2 + (coor_y_dna - coor_y_pro)**2 + (coor_z_dna - coor_z_pro)**2)
                if dist <= cut_off :
                    flag3 = 1
                    num_bind3 = num_bind3 + 1
                    break
            if flag3 == 1 :
                break
    line_new = str(i) + '    ' + str(num_bind) + '    ' + str(num_bind1) + '    ' + str(num_bind2) + '    ' + str(num_bind3) + '\n'
    fp_out.writelines(line_new)
    print(i, line_new)


'''
t1 = t.superpose(reference = t, frame = 0, atom_indices = ca_index)
#print(t1.xyz[0][332])
mc = md.compute_center_of_mass(t1)
#print(mc)
lamb = 0.08

atom_ind = @atom@
atom_ind_b = atom_ind + 2
atom_ind_b_comp = 1333 - atom_ind_b
atom_ind_b_nb = atom_ind_b + 3 

x0 = t1.xyz[0][atom_ind][0]
y0 = t1.xyz[0][atom_ind][1]
z0 = t1.xyz[0][atom_ind][2]

mc_x0 = mc[0][0]
mc_y0 = mc[0][1]
mc_z0 = mc[0][2]

p0_x = x0 - mc_x0
p0_y = y0 - mc_y0
p0_z = z0 - mc_z0

p0 = (p0_x, p0_y, p0_z)

dist0 = np.sqrt(p0_x**2 + p0_y**2 + p0_z**2)

fp = open('trans.dat', 'w')

n_frame = len(t1)
for i in range(1, n_frame):
    x = t1.xyz[i][atom_ind][0]
    y = t1.xyz[i][atom_ind][1]
    z = t1.xyz[i][atom_ind][2]
    mc_x = mc[i][0]
    mc_y = mc[i][1]
    mc_z = mc[i][2]
    p_x = x - mc_x
    p_y = y - mc_y
    p_z = z - mc_z
    p = (p_x, p_y, p_z)
    dist = np.sqrt(p_x**2 + p_y**2 + p_z**2)
    dot_p = p_x * p0_x + p_y * p0_y + p_z * p0_z
    #math.acos(dot_p / (dist * dist0))
    f = np.cross(p, p0)
    trans = 0
    rot = 0
    if f[2] <= 0 :
        trans = math.acos(dot_p / (dist * dist0)) / lamb
    if f[2] > 0 :
        trans = -math.acos(dot_p / (dist * dist0)) / lamb

    x_b = t1.xyz[i][atom_ind_b][0]
    y_b = t1.xyz[i][atom_ind_b][1]
    z_b = t1.xyz[i][atom_ind_b][2]

    x_b_comp = t1.xyz[i][atom_ind_b_comp][0]
    y_b_comp = t1.xyz[i][atom_ind_b_comp][1]
    z_b_comp = t1.xyz[i][atom_ind_b_comp][2]

    x_b_nb = t1.xyz[i][atom_ind_b_nb][0]
    y_b_nb = t1.xyz[i][atom_ind_b_nb][1]
    z_b_nb = t1.xyz[i][atom_ind_b_nb][2]

    b_x = x_b_comp - x_b
    b_y = y_b_comp - y_b
    b_z = z_b_comp - z_b
    b = (b_x, b_y, b_z)

    dist_b = np.sqrt(b_x**2 + b_y**2 + b_z**2)
    dot_b = p_x * b_x + p_y * b_y + p_z * b_z

    d_x = x_b_nb - x_b  
    d_y = y_b_nb - x_b  
    d_z = z_b_nb - x_b

    d = (d_x, d_y, d_z)
    tmp = np.cross(p, b)
    flag = tmp[0]*d_x + tmp[1]*d_y + tmp[2]*d_z
    if flag <= 0 :
        rot = math.acos(dot_b / (dist * dist_b))
    if flag > 0 :
        rot = -math.acos(dot_b / (dist * dist_b))


    line = str(i) + '    ' + str(-trans) + '    ' + str(-rot) + '\n'
    fp.writelines(line)
fp.close()
'''
