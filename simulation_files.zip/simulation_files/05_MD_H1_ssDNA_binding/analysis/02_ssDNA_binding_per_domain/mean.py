import numpy as np
data1 = np.loadtxt('dna_bind_1.dat')
data2 = np.loadtxt('dna_bind_2.dat')
data3 = np.loadtxt('dna_bind_3.dat')
p = []
p.append(data1[0])
p.append(data2[0])
p.append(data3[0])
p = np.array(p)
print(np.mean(p), np.std(p))

p = []
p.append(data1[1])
p.append(data2[1])
p.append(data3[1])
p = np.array(p)
print(np.mean(p), np.std(p))

p = []
p.append(data1[2])
p.append(data2[2])
p.append(data3[2])
p = np.array(p)
print(np.mean(p), np.std(p))
