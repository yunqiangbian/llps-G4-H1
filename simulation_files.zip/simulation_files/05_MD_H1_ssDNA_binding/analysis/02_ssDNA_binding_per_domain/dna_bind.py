import matplotlib.pyplot as plt
import numpy as np

num_core = []
num_od =[]
num_ctd = []

cut_off = 5

n_frame = 0

frame_start = 0

num1 = 0
num2 = 0
num3 = 0

data = np.loadtxt('col')

fp1 = open('dna_bind_1.dat', 'w')
fp2 = open('dna_bind_2.dat', 'w')
fp3 = open('dna_bind_3.dat', 'w')

for i in range(1000) :
    if data[i][1] >= cut_off :
        num1 += 1
    if data[i][2] >= cut_off :
        num2 += 1
    if data[i][3] >= cut_off :
        num3 += 1
    line = '%f    %f    %f\n' % (num1/1000, num2/1000, num3/1000)
    fp1.writelines(line)

for i in range(1000, 2000) :
    if data[i][1] >= cut_off :
        num1 += 1
    if data[i][2] >= cut_off :
        num2 += 1
    if data[i][3] >= cut_off :
        num3 += 1
    line = '%f    %f    %f\n' % (num1/1000, num2/1000, num3/1000)
    fp2.writelines(line)

for i in range(2000, 3000) :
    if data[i][1] >= cut_off :
        num1 += 1
    if data[i][2] >= cut_off :
        num2 += 1
    if data[i][3] >= cut_off :
        num3 += 1
    line = '%f    %f    %f\n' % (num1/1000, num2/1000, num3/1000)
    fp3.writelines(line)
