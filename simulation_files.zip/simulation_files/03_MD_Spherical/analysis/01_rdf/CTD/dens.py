import numpy as np
mass_dna = { 'DA': 134.100, 'DG': 150.100, 'DC': 110.100, 'DT': 125.100, 'DP': 94.970, 'DS': 83.110 }
mass_pro = { 'ALA': 71.090, 'ARG': 156.190, 'ASN': 114.110, 'ASP': 115.090, 'CYS': 103.150, 'GLN': 128.140, 'GLU': 129.120, 'GLY': 57.050, 'HIS': 137.140, 'ILE': 113.160, 'LEU': 113.160, 'LYS': 128.170, 'MET': 131.190, 'PHE': 147.180, 'PRO': 97.120, 'SER': 87.080, 'THR': 101.110, 'TRP': 186.210, 'TYR': 163.180, 'VAL': 99.140 }

mass_unit = 1.66 * ( 10 ** (-21) )
center_x = 0
a = 240.0 * (10 ** (-10))
b = 240.0 * (10 ** (-10))

stride = 1

n_res = 38 * 480

flag = 0
for i in range (9980, 10000) :
    print(i)
    fp_pro_name = 'dens_pro_' + str(i) + '_step.dat'
    fp_pro = open(fp_pro_name, 'w')
    fp_name1 = 'coor_x_pro_' + str(i) + '.dat'
    fp1 = open(fp_name1, 'r')
    conts1 = fp1.readlines()
    fp1.close()

    fp_name2 = 'coor_y_pro_' + str(i) + '.dat'
    fp2 = open(fp_name2, 'r')
    conts2 = fp2.readlines()
    fp2.close()

    fp_name3 = 'coor_z_pro_' + str(i) + '.dat'
    fp3 = open(fp_name3, 'r')
    conts3 = fp3.readlines()
    fp3.close()

    #fp_out_dna = open(fp_out_name1, 'w')

    coor_x = conts1[2].split()
    coor_y = conts2[2].split()
    coor_z = conts3[2].split()
    atom = conts1[0].split()

    y_min = -350
    y_max = 350
    yy = y_min
    y_incr = 10
    while yy <= y_max :
        z_min = -350
        z_max = 350
        zz = z_min
        z_incr = 10
        while zz <= z_max :
            num = 0
            for k in range(len(atom)) :
                x = float(coor_x[k])
                y = float(coor_y[k])
                z = float(coor_z[k])
                if x > -40 and x< 40 :
                    if y >= yy-y_incr/2 and y< yy+y_incr/2 and z >= zz-z_incr/2 and z< zz+z_incr/2 :
                        num += 1
            prb = num/n_res
            line = str(yy) + '    ' + str(zz) + '    ' + str(prb) + '\n'
            fp_pro.writelines(line)
            zz += z_incr
        yy += y_incr
    fp_pro.close()
