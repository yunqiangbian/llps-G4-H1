import numpy as np
num = 20
fp = open('dens_mean.dat', 'w')
data1 = np.loadtxt('dens_pro_9980_step.dat')
data2 = np.loadtxt('dens_pro_9981_step.dat')
data3 = np.loadtxt('dens_pro_9982_step.dat')
data4 = np.loadtxt('dens_pro_9983_step.dat')
data5 = np.loadtxt('dens_pro_9984_step.dat')
data6 = np.loadtxt('dens_pro_9985_step.dat')
data7 = np.loadtxt('dens_pro_9986_step.dat')
data8 = np.loadtxt('dens_pro_9987_step.dat')
data9 = np.loadtxt('dens_pro_9988_step.dat')
data10 = np.loadtxt('dens_pro_9989_step.dat')
data11 = np.loadtxt('dens_pro_9990_step.dat')
data12 = np.loadtxt('dens_pro_9991_step.dat')
data13 = np.loadtxt('dens_pro_9992_step.dat')
data14 = np.loadtxt('dens_pro_9993_step.dat')
data15 = np.loadtxt('dens_pro_9994_step.dat')
data16 = np.loadtxt('dens_pro_9995_step.dat')
data17 = np.loadtxt('dens_pro_9996_step.dat')
data18 = np.loadtxt('dens_pro_9997_step.dat')
data19 = np.loadtxt('dens_pro_9998_step.dat')
data20 = np.loadtxt('dens_pro_9999_step.dat')
y = data1[:, 0]
z = data1[:, 1]
for i in range(len(y)) :
    summ = 0
    summ = data1[:, 2][i] + data2[:, 2][i] + data3[:, 2][i] + data4[:, 2][i] + data5[:, 2][i] + data6[:, 2][i] + data7[:, 2][i] + data8[:, 2][i] + data9[:, 2][i] + data10[:, 2][i] + data11[:, 2][i] + data12[:, 2][i] + data13[:, 2][i] + data14[:, 2][i] + data15[:, 2][i] + data16[:, 2][i] + data17[:, 2][i] + data18[:, 2][i] + data19[:, 2][i] + data20[:, 2][i]
    p = summ / num * 480 / 60
    line = str(y[i]) + '    ' + str(z[i]) + '    ' + str(p) + '\n'
    fp.writelines(line)
fp.close()


